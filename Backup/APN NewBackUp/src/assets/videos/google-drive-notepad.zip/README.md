# Google Drive Notepad

A small React + Express CRUD notepad. Notes are saved to a private `notes.json` file in Google Drive.

## Requirements

- Node.js 18+
- A Google Cloud project with the Google Drive API enabled
- A Google service account JSON key

## 1. Set up Google Drive

1. In Google Cloud Console, create/select a project and enable **Google Drive API**.
2. Create a service account and create/download a JSON key for it.
3. Copy the service account's `client_email`.
4. In Google Drive, create a folder (recommended) and share that folder with the service-account email as an **Editor**.
5. Copy the folder ID from its Drive URL. For a URL like `https://drive.google.com/drive/folders/FOLDER_ID`, the folder ID is the final part.

Keep the service-account key private. Do not put it in the React client or commit it to GitHub.

## 2. Start the backend

```bash
cd server
npm install
```

Copy `.env.example` to `.env`. Set `GOOGLE_SERVICE_ACCOUNT_JSON` to the entire downloaded service-account JSON as a single-line JSON value. Set `GOOGLE_DRIVE_FOLDER_ID` to the folder ID you shared with the service account.

For the private key, preserve the escaped `\\n` characters if entering JSON as one line. If using a hosting dashboard, paste the full JSON object as the environment variable value.

Then run:

```bash
npm run dev
```

Backend: `http://localhost:5000`
Health check: `http://localhost:5000/api/health`

The first successful `GET /api/notes` creates `notes.json` in the configured folder if it does not exist.

## 3. Start the frontend

Open a second terminal:

```bash
cd client
npm install
npm run dev
```

Open the URL Vite prints, usually `http://localhost:5173`.

Optional: create `client/.env` and set `VITE_API_URL=http://localhost:5000` if your API is hosted elsewhere.

## API routes

- `GET /api/health` — API health
- `GET /api/notes` — list notes
- `POST /api/notes` — create a note (`{ "title": "...", "content": "..." }`)
- `PUT /api/notes/:id` — update a note
- `DELETE /api/notes/:id` — delete a note

## Important notes

- This demo has no user login. Do not deploy it publicly as-is; add authentication and rate limiting first.
- It stores all notes in one JSON file, so it is intended for a small personal demo, not many concurrent users.
- Google Drive storage and API use are subject to your account's storage and quota limits.
