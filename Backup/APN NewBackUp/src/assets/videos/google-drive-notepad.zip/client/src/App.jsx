import { useCallback, useEffect, useMemo, useState } from "react";
import { FileText, Plus, Search, Save, X, Pencil, Trash2, Cloud, RefreshCw, StickyNote } from "lucide-react";

const API = import.meta.env.VITE_API_URL || "http://localhost:5000";

async function request(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}

function formatDate(value) {
  if (!value) return "";
  return new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(new Date(value));
}

export default function App() {
  const [notes, setNotes] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const refresh = useCallback(async (keepSelection = true) => {
    setLoading(true);
    setError("");
    try {
      const data = await request("/api/notes");
      setNotes(data);
      if (keepSelection && selectedId && data.some((note) => note.id === selectedId)) {
        const active = data.find((note) => note.id === selectedId);
        setTitle(active.title);
        setContent(active.content);
      } else if (!keepSelection) {
        setSelectedId(null);
        setTitle("");
        setContent("");
      } else if (!selectedId && data.length) {
        // Leave the editor blank until the user selects a note.
      }
    } catch (err) {
      setError(`${err.message}. Check the backend and Google Drive credentials.`);
    } finally {
      setLoading(false);
    }
  }, [selectedId]);

  useEffect(() => { refresh(); }, []); // Load notes on first render.

  const filteredNotes = useMemo(() => {
    const term = search.toLowerCase().trim();
    if (!term) return notes;
    return notes.filter((note) => `${note.title} ${note.content}`.toLowerCase().includes(term));
  }, [notes, search]);

  function newNote() {
    setSelectedId(null);
    setTitle("");
    setContent("");
    setError("");
    setMessage("");
  }

  function selectNote(note) {
    setSelectedId(note.id);
    setTitle(note.title);
    setContent(note.content);
    setError("");
    setMessage("");
  }

  async function saveNote(event) {
    event.preventDefault();
    if (!title.trim() || !content.trim()) {
      setError("Enter a title and some note content before saving.");
      return;
    }
    setSaving(true);
    setError("");
    setMessage("");
    try {
      const isEditing = Boolean(selectedId);
      const saved = await request(isEditing ? `/api/notes/${selectedId}` : "/api/notes", {
        method: isEditing ? "PUT" : "POST",
        body: JSON.stringify({ title, content }),
      });
      const data = await request("/api/notes");
      setNotes(data);
      setSelectedId(saved.id);
      setTitle(saved.title);
      setContent(saved.content);
      setMessage(isEditing ? "Note updated in Google Drive." : "Note saved to Google Drive.");
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function deleteNote() {
    if (!selectedId) return;
    if (!window.confirm("Delete this note permanently from your notes file?")) return;
    setSaving(true);
    setError("");
    try {
      await request(`/api/notes/${selectedId}`, { method: "DELETE" });
      const data = await request("/api/notes");
      setNotes(data);
      newNote();
      setMessage("Note deleted.");
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  const selectedNote = notes.find((note) => note.id === selectedId);

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-icon"><StickyNote size={23} /></div>
          <div><strong>Drive Notepad</strong><span>Your notes, saved in your Drive</span></div>
        </div>
        <div className="cloud-status"><span className="status-dot" /> Google Drive storage</div>
      </header>

      <section className="workspace">
        <aside className="sidebar">
          <button className="new-note-button" onClick={newNote}><Plus size={18} /> New note</button>
          <div className="searchbox"><Search size={17} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search notes..." /></div>
          <div className="notes-heading"><span>YOUR NOTES</span><span>{filteredNotes.length}</span></div>
          <div className="notes-list">
            {loading && <div className="empty-state">Loading notes…</div>}
            {!loading && filteredNotes.map((note) => (
              <button key={note.id} className={`note-item ${selectedId === note.id ? "active" : ""}`} onClick={() => selectNote(note)}>
                <div className="note-item-title"><FileText size={16} /><span>{note.title}</span></div>
                <p>{note.content}</p>
                <small>{formatDate(note.updatedAt)}</small>
              </button>
            ))}
            {!loading && filteredNotes.length === 0 && <div className="empty-state">{search ? "No notes match your search." : "No notes yet. Create your first note."}</div>}
          </div>
          <button className="refresh-button" onClick={() => refresh()}><RefreshCw size={15} /> Refresh from Drive</button>
        </aside>

        <section className="editor-panel">
          <div className="editor-topline">
            <div className="document-label"><FileText size={16} /> {selectedId ? "EDITING NOTE" : "NEW NOTE"}</div>
            {selectedNote && <span className="updated-label">Updated {formatDate(selectedNote.updatedAt)}</span>}
          </div>
          <form className="editor-form" onSubmit={saveNote}>
            <input className="title-input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Give your note a title..." maxLength={160} />
            <textarea className="content-input" value={content} onChange={(e) => setContent(e.target.value)} placeholder="Start writing here…" maxLength={20000} />
            <div className="editor-footer">
              <span>{content.length.toLocaleString()} / 20,000 characters</span>
              <div className="actions">
                {selectedId && <button type="button" className="delete-button" onClick={deleteNote} disabled={saving}><Trash2 size={16} /> Delete</button>}
                {(title || content || selectedId) && <button type="button" className="clear-button" onClick={newNote} disabled={saving}><X size={16} /> Clear</button>}
                <button type="submit" className="save-button" disabled={saving}><Save size={16} /> {saving ? "Saving…" : selectedId ? "Update note" : "Save note"}</button>
              </div>
            </div>
          </form>
          {(error || message) && <div className={`notice ${error ? "error" : "success"}`}>{error || message}</div>}
          <div className="privacy-hint"><Cloud size={17} /><span>Notes are stored in your Google Drive through your private Node.js backend.</span></div>
        </section>
      </section>
      <footer className="page-footer">Simple notes. Stored in your Drive.</footer>
    </main>
  );
}