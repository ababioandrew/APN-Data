import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { google } from "googleapis";
import { Readable } from "node:stream";
import { randomUUID } from "node:crypto";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors({
  origin: process.env.FRONTEND_URL
    ? [process.env.FRONTEND_URL, "http://localhost:5173"]
    : ["http://localhost:5173"],
}));
app.use(express.json({ limit: "1mb" }));

function getDriveClient() {
  const raw = process.env.GOOGLE_SERVICE_ACCOUNT_JSON;
  if (!raw) throw new Error("GOOGLE_SERVICE_ACCOUNT_JSON is not configured.");

  let credentials;
  try {
    credentials = JSON.parse(raw);
  } catch {
    throw new Error("GOOGLE_SERVICE_ACCOUNT_JSON must contain valid JSON.");
  }

  const auth = new google.auth.GoogleAuth({
    credentials,
    scopes: ["https://www.googleapis.com/auth/drive"],
  });
  return google.drive({ version: "v3", auth });
}

let notesFileId;

async function findOrCreateNotesFile(drive) {
  if (notesFileId) return notesFileId;

  const folderId = process.env.GOOGLE_DRIVE_FOLDER_ID;
  const clauses = [
    "name = 'notes.json'",
    "mimeType = 'application/json'",
    "trashed = false",
  ];
  if (folderId) clauses.push(`'${folderId.replace(/'/g, "\\'")}' in parents`);

  const listed = await drive.files.list({
    q: clauses.join(" and "),
    pageSize: 10,
    fields: "files(id,name,mimeType)",
    spaces: "drive",
  });

  if (listed.data.files?.length) {
    notesFileId = listed.data.files[0].id;
    return notesFileId;
  }

  const initialNotes = [];
  const created = await drive.files.create({
    requestBody: {
      name: "notes.json",
      mimeType: "application/json",
      ...(folderId ? { parents: [folderId] } : {}),
    },
    media: {
      mimeType: "application/json",
      body: Readable.from([JSON.stringify(initialNotes, null, 2)]),
    },
    fields: "id,name",
  });

  notesFileId = created.data.id;
  return notesFileId;
}

async function readNotes(drive, fileId) {
  const response = await drive.files.get(
    { fileId, alt: "media" },
    { responseType: "stream" },
  );

  let contents = "";
  for await (const chunk of response.data) contents += chunk.toString("utf8");
  if (!contents.trim()) return [];
  const parsed = JSON.parse(contents);
  if (!Array.isArray(parsed)) throw new Error("notes.json must contain a JSON array.");
  return parsed;
}

async function writeNotes(drive, fileId, notes) {
  await drive.files.update({
    fileId,
    media: {
      mimeType: "application/json",
      body: Readable.from([JSON.stringify(notes, null, 2)]),
    },
  });
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "Google Drive Notepad API" });
});

app.get("/api/notes", async (_req, res) => {
  try {
    const drive = getDriveClient();
    const fileId = await findOrCreateNotesFile(drive);
    const notes = await readNotes(drive, fileId);
    res.json(notes.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt)));
  } catch (error) {
    console.error("GET /api/notes:", error.message);
    res.status(500).json({ error: error.message || "Could not read notes from Google Drive." });
  }
});

app.post("/api/notes", async (req, res) => {
  try {
    const title = String(req.body.title || "").trim();
    const content = String(req.body.content || "").trim();
    if (!title || !content) {
      return res.status(400).json({ error: "Both title and note content are required." });
    }

    const drive = getDriveClient();
    const fileId = await findOrCreateNotesFile(drive);
    const notes = await readNotes(drive, fileId);
    const now = new Date().toISOString();
    const note = {
      id: randomUUID(),
      title: title.slice(0, 160),
      content: content.slice(0, 20000),
      createdAt: now,
      updatedAt: now,
    };
    notes.push(note);
    await writeNotes(drive, fileId, notes);
    res.status(201).json(note);
  } catch (error) {
    console.error("POST /api/notes:", error.message);
    res.status(500).json({ error: error.message || "Could not save note." });
  }
});

app.put("/api/notes/:id", async (req, res) => {
  try {
    const title = String(req.body.title || "").trim();
    const content = String(req.body.content || "").trim();
    if (!title || !content) {
      return res.status(400).json({ error: "Both title and note content are required." });
    }

    const drive = getDriveClient();
    const fileId = await findOrCreateNotesFile(drive);
    const notes = await readNotes(drive, fileId);
    const index = notes.findIndex((item) => item.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: "Note not found." });

    notes[index] = {
      ...notes[index],
      title: title.slice(0, 160),
      content: content.slice(0, 20000),
      updatedAt: new Date().toISOString(),
    };
    await writeNotes(drive, fileId, notes);
    res.json(notes[index]);
  } catch (error) {
    console.error("PUT /api/notes/:id:", error.message);
    res.status(500).json({ error: error.message || "Could not update note." });
  }
});

app.delete("/api/notes/:id", async (req, res) => {
  try {
    const drive = getDriveClient();
    const fileId = await findOrCreateNotesFile(drive);
    const notes = await readNotes(drive, fileId);
    const remaining = notes.filter((item) => item.id !== req.params.id);
    if (remaining.length === notes.length) {
      return res.status(404).json({ error: "Note not found." });
    }
    await writeNotes(drive, fileId, remaining);
    res.json({ ok: true, message: "Note deleted." });
  } catch (error) {
    console.error("DELETE /api/notes/:id:", error.message);
    res.status(500).json({ error: error.message || "Could not delete note." });
  }
});

app.listen(PORT, () => {
  console.log(`Google Drive Notepad API running at http://localhost:${PORT}`);
});